package com.breadwinner.wavecastremote

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.Inet4Address
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.net.Socket
import java.net.URL
import java.net.URLEncoder

/** The phone being controlled. */
class Target(val host: String, val port: Int, val pin: String) {
    val addr: String get() = "$host:$port"
    fun url(path: String): String = "http://$host:$port$path"
}

object Net {
    fun enc(s: String): String = URLEncoder.encode(s, "UTF-8")

    /** Understands "http://192.168.1.5:8080/?pin=1234" from the QR code, or a typed "192.168.1.5". */
    fun parseTarget(text: String, pinFallback: String = ""): Target? {
        var a = text.trim()
        if (a.isEmpty()) return null
        var pin = pinFallback
        val m = Regex("[?&]pin=([A-Za-z0-9]+)").find(a)
        if (m != null) pin = m.groupValues[1]
        a = a.removePrefix("http://").removePrefix("https://")
        val slash = a.indexOf('/')
        if (slash >= 0) a = a.substring(0, slash)
        if (a.isEmpty()) return null
        val parts = a.split(":")
        val host = parts[0]
        var port = 8080
        if (parts.size > 1) {
            val p = parts[1].toIntOrNull()
            if (p == null) return null
            port = p
        }
        if (host.isEmpty()) return null
        return Target(host, port, pin)
    }

    /** Sends one command. Returns (worked, reason). */
    fun ctl(t: Target, vararg kv: String): Pair<Boolean, String> {
        return try {
            val c = URL(t.url("/ctl")).openConnection() as HttpURLConnection
            c.requestMethod = "POST"
            c.doOutput = true
            c.connectTimeout = 3000
            c.readTimeout = 8000
            val sb = StringBuilder("pin=").append(enc(t.pin))
            var i = 0
            while (i + 1 < kv.size) {
                sb.append('&').append(enc(kv[i])).append('=').append(enc(kv[i + 1]))
                i += 2
            }
            val body = sb.toString().toByteArray()
            c.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }
            val code = c.responseCode
            val stream = if (code >= 400) c.errorStream else c.inputStream
            val txt = stream?.use { it.readBytes().toString(Charsets.UTF_8) } ?: ""
            val j = try { JSONObject(txt) } catch (e: Exception) { JSONObject() }
            j.optBoolean("ok", false) to j.optString("err", "")
        } catch (e: Exception) {
            false to "net"
        }
    }

    fun words(err: String): String = when (err) {
        "off" -> "Control is switched off in WaveCast on the other phone."
        "acc" -> "On the other phone: turn on WaveCast under Accessibility."
        "pin" -> "Wrong PIN."
        "locked" -> "Too many tries. Wait 30 seconds."
        "net" -> "Lost the other phone."
        "field" -> "Tap a text box on the other phone first."
        else -> "That did not work."
    }

    // ───── remembering the last phone ─────
    fun save(c: Context, t: Target) {
        c.getSharedPreferences("wcr", Context.MODE_PRIVATE).edit().putString("addr", t.addr).putString("pin", t.pin).apply()
    }

    fun last(c: Context): Target? {
        val p = c.getSharedPreferences("wcr", Context.MODE_PRIVATE)
        val a = p.getString("addr", null) ?: return null
        return parseTarget(a, p.getString("pin", "") ?: "")
    }

    // ───── finding WaveCast phones on the same network ─────
    private fun isWaveCast(host: String, port: Int): Boolean {
        val s = Socket()
        return try {
            s.connect(InetSocketAddress(host, port), 400)
            s.soTimeout = 800
            s.getOutputStream().write("GET /ping HTTP/1.0\r\n\r\n".toByteArray())
            val buf = ByteArray(512)
            val n = s.getInputStream().read(buf)
            n > 0 && String(buf, 0, n).contains("X-T", ignoreCase = true)
        } catch (e: Exception) {
            false
        } finally {
            try { s.close() } catch (e: Exception) { }
        }
    }

    suspend fun find(): List<Target> = withContext(Dispatchers.IO) {
        val bases = LinkedHashSet<String>()
        val mine = HashSet<String>()
        try {
            val all = NetworkInterface.getNetworkInterfaces()
            if (all != null) {
                for (ni in all) {
                    if (!ni.isUp || ni.isLoopback) continue
                    for (a in ni.inetAddresses) {
                        if (a is Inet4Address && a.isSiteLocalAddress) {
                            val h = a.hostAddress ?: continue
                            mine.add(h)
                            bases.add(h.substringBeforeLast('.'))
                        }
                    }
                }
            }
        } catch (e: Exception) {
        }
        val sem = Semaphore(80)
        val found = ArrayList<Target>()
        coroutineScope {
            val jobs = ArrayList<kotlinx.coroutines.Deferred<Unit>>()
            for (b in bases) {
                for (i in 1..254) {
                    val host = "$b.$i"
                    if (host in mine) continue
                    for (port in 8080..8082) {
                        jobs.add(async {
                            sem.withPermit {
                                val hit = isWaveCast(host, port)
                                if (hit) {
                                    synchronized(found) { found.add(Target(host, port, "")) }
                                }
                                Unit
                            }
                        })
                    }
                }
            }
            jobs.awaitAll()
        }
        found.sortedBy { it.addr }
    }
}
